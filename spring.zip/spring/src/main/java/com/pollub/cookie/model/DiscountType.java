package com.pollub.cookie.model;

public enum DiscountType {
    PERCENTAGE,
    FIXED_AMOUNT
}
