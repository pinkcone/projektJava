package com.pollub.cookie.model;

public enum OrderStatus {
    NOWE,
    W_TRAKCIE_PRZETWARZANIA,
    WYSŁANE,
    DOSTARCZONE,
    ANULOWANE
}

