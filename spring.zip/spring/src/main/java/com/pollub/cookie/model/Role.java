package com.pollub.cookie.model;

public enum Role {
    ADMIN,
    USER
}

